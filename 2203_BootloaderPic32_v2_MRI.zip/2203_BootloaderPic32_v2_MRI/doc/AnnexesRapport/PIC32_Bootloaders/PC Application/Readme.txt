PIC32UBL folder contains the host PC application.
This is a MFC based VC++ application develped using "Microsoft Visual Studio .Net 2003".

To build the application follow these steps.

1) Open "PIC32UBL.sln" with "Microsoft Visual Studio. Net 2003". This will open the workspace.
2) Select "Debug" or "Release" configuration. You can do this by navigating to menu "Build"->"Configuration Manager" 
and selecting "Debug" or "Release" from the drop down menu found under "Active Solution Configuration:".
3) Go to "Build" menu and click on "Build Solution" to build the project. The debug version of the exe and the release version
of the exe can be found inside the debug and release directories respectively.




